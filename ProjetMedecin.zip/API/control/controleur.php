<?php

class controleur 
{
	public function inscriptionPatient()
	{
		$corpsRequete = file_get_contents('php://input');
		
		if($json = json_decode($corpsRequete, true)) {
			if(count($json) == 8) 
			{
				$inscription =(new patient)->inscription($json["nomPatient"],$json["prenomPatient"],$json["ruePatient"],$json["cpPatient"],$json["villePatient"],$json["loginPatient"],$json["mdpPatient"]);
				if ($inscription)
				{
					http_response_code(201);
					$json = '{ "code":201, "message": "Patient inscrit" }';
					(new vue)->afficherJSON($json);
				}
	}
}
?>