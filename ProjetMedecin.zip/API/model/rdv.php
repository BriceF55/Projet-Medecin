<?php

class rdv 
{
    // Objet PDO servant à la connexion à la base
	private $pdo;

	// Connexion à la base de données
	public function __construct() 
	{
		$config = parse_ini_file("config.ini");
		try 
		{
			$this->pdo = new \PDO("mysql:host=".$config["host"].";dbname=".$config["database"].";charset=utf8", $config["user"], $config["password"]);
		} catch(Exception $e) 
		{
			echo $e->getMessage();
		}
    }
    public function getAll() 
	{
		$sql = "SELECT * FROM rdv";
		$req = $this->pdo->prepare($sql);
		$req->execute();
		return $req->fetchAll(PDO::FETCH_ASSOC);
	}
	public function getRDV($id)
	{
		$sql = "SELECT * FROM rdv WHERE idRdv = :id";
		$req = $this->pdo->prepare($sql);
		$req->bindParam(':id', $id, PDO::PARAM_INT);
		$req->execute();
		return $req->fetch(PDO::FETCH_ASSOC);
	}

	public function ajouterRDV($id, $dateHeure, $idPatient, $idMedecin)
	{
		$sql = "INSERT INTO rdv (idRdv, dateHeureRdv, idPatient, idMedecin) VALUES (:id, :dateHeure, :idPatient, :idMedecin)";
		$req = $this->pdo->prepare($sql);
		$req->bindParam(':id', $id, PDO::PARAM_INT);
		$req->bindParam(':dateHeure', $dateHeure, PDO::PARAM_STR);
		$req->bindParam(':idPatient', $idPatient, PDO::PARAM_INT);
		$req->bindParam(':idMedecin', $idMedecin, PDO::PARAM_INT);
		return $req->execute();
	}
	
	public function annulerRDV($id) 
	{
		$sql = "DELETE FROM rdv WHERE idRdv = :id";
		$req = $this->pdo->prepare($sql);
		$req->bindParam(':id', $id, PDO::PARAM_INT);
		return $req->execute();
	}
	
	public function modifierRDV($id, $dateHeure = null, $idPatient = null, $idMedecin = null)
	{
		$sql = "UPDATE rdv SET idRdv = :id";
		if($dateHeure != null) 
		{
			$sql = ", dateHeureRdv = :dateHeure";
		}
		if($idMedecin != null)
		{
			$sql = ", idMedecin = :idMedecin";
		}
		if($idPatient != null)
		{
			$sql = ", idPatient = :idPatient";
		}
		$sql = " WHERE idRdv = :id ";
		$req = $this->pdo->prepare($sql);
		$req->bindParam(':id', $id, PDO::PARAM_STR);
		if($dateHeure != null) 
		{
			$req->bindParam(':dateHeure', $dateHeure, PDO::PARAM_STR);
		}
		if($idPatient != null) 
		{
			$req->bindParam(':idPatient', $idPatient, PDO::PARAM_INT);
		}
				if($idMedecin != null) 
		{
			$req->bindParam(':idMedecin', $idMedecin, PDO::PARAM_INT);
		}
		return $req->execute();
	}
}
?>